#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author: rjayapalan
Created: March 10, 2022
"""

DEFAULT_CHUNK_SIZE = 1000000  # 1 MB

SPLIT_DELIMITER = '_'

MANIFEST_FILE_NAME = 'manifest'